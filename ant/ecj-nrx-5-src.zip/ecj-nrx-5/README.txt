This is the java compiler which is included in eclipse environment, based on the I20201218-1800 tag in github repo eclipse.jdt.core.
It is included in the NetRexxF.jar and used when -ecj option is provided on NetRexxC. 
Four files are modified:

org/eclipse/jdt/core/JDTCompilerAdapter.java	
 	Sets compiler option -source and -target to 1.8 as defaults.
 	This is the compiler called by the NetRexx ant task during build

org/eclipse/jdt/internal/compiler/batch/Main.java
	Overrides -source and -target when duplicate, take latest given

org/eclipse/jdt/internal/compiler/tool/EclipseCompilerImpl.java
	Does not abort when .java is absent, NetRexxC compiles from memory

org/eclipse/jdt/internal/compiler/tool/EclipseCompiler.java
	Sets compiler option -source, -target and -release (compliance) to 1.8 as defaults
	This is the compiler called by NetRexx compile when -ecj option is given.
	Can be overridden by -targetvm option on NetRexxC

